// Legacy image provider helper retained for compatibility only.
// Active image generation now routes through VPS 4 -> VPS 2.
export async function generatePixazoImage(){ throw new Error('Legacy Pixazo route disabled: use VPS 4 gateway -> VPS 2 Qwen-Image'); }
export const generateCloudflareImage = generatePixazoImage;
export const generatePollinationsImage = generatePixazoImage;
