# ONYX AI — 4 VPS Qwen deployment

Hardware reported for the VPS: 48 vCPU AMD EPYC 9655P, 200+ GB RAM, no NVIDIA compute GPU (Virtio GPU only).

## Model assignment
1. VPS 1: Qwen3-30B-A3B (quantized for CPU), llama.cpp / llama-server.
2. VPS 2: Qwen-Image, CPU/offload-capable image stack.
3. VPS 3: Qwen-Image-Edit-2511, CPU/offload-capable image stack.
4. VPS 4: ONYX Gateway + Nginx + WireGuard + all provider API keys.

## Important
Image models on CPU will be very slow. The gateway does not put model keys in the frontend.

## Frontend environment
Set only:
- `ONYX_GATEWAY_URL`
- `ONYX_GATEWAY_SECRET`

Do NOT set XKIRO_API_KEY, OPENROUTER_API_KEY, GROQ_API_KEY, PIXAZO_API_KEY or model-provider keys on Vercel for this architecture.

## Gateway
Copy `gateway/.env.example` to `gateway/.env` on VPS 4 and set a long random `GATEWAY_SECRET`.

## Nginx
Expose only VPS 4 over HTTPS. Keep ports 8000/8188 on VPS 1–3 bound to WireGuard/private interfaces or firewall them from the public internet.
