# ONYX AI Gateway (VPS 4)

VPS 4 is the only public API gateway. Frontend never receives provider/model API keys.

## Private network expected
- VPS 4: 10.20.0.1
- VPS 1 chat: 10.20.0.2:8000
- VPS 2 image: 10.20.0.3:8188
- VPS 3 edit: 10.20.0.4:8188

Set the upstream URLs in `.env` if your WireGuard addresses differ.

## Routes
- `POST /v1/chat/completions` -> VPS 1
- `POST /v1/images/generations` -> VPS 2
- `POST /v1/images/edits` -> VPS 3
- `POST /v1/search` -> Tavily (key stays on VPS 4)
- `GET /health`

The image upstreams are deliberately configurable because ComfyUI workflow endpoints differ by deployment. Point `VPS2_IMAGE_URL` and `VPS3_EDIT_URL` at the small adapter endpoints running beside ComfyUI.
