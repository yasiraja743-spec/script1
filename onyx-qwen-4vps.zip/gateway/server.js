import http from 'node:http';
import { URL } from 'node:url';

const PORT=Number(process.env.PORT||8080);
const SECRET=process.env.GATEWAY_SECRET||'';
const CHAT_URL=process.env.VPS1_CHAT_URL||'http://10.20.0.2:8000/v1/chat/completions';
const IMAGE_URL=process.env.VPS2_IMAGE_URL||'http://10.20.0.3:8188/generate';
const EDIT_URL=process.env.VPS3_EDIT_URL||'http://10.20.0.4:8188/edit';
const TAVILY=process.env.TAVILY_API_KEY||'';

function send(res,status,data,ct='application/json; charset=utf-8'){res.writeHead(status,{'Content-Type':ct,'Cache-Control':'no-store'});res.end(typeof data==='string'?data:JSON.stringify(data));}
async function body(req){let a=[];for await(const c of req)a.push(c);return Buffer.concat(a);}
async function jsonBody(req){const b=await body(req);try{return JSON.parse(b.toString()||'{}')}catch{return {}}}
function authorized(req){return SECRET && req.headers['x-onyx-gateway-key']===SECRET;}
async function proxyJson(res,url,payload){
  const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json,text/event-stream,image/*,*/*'},body:JSON.stringify(payload)});
  const ct=r.headers.get('content-type')||''; const b=Buffer.from(await r.arrayBuffer());
  res.writeHead(r.status,{'Content-Type':ct||'application/octet-stream','Cache-Control':'no-store'});res.end(b);
}
const server=http.createServer(async(req,res)=>{
 try{
  const u=new URL(req.url,`http://${req.headers.host}`);
  if(u.pathname==='/health') return send(res,200,{status:true,service:'ONYX AI Gateway',routes:{chat:true,generate:true,edit:true,search:Boolean(TAVILY)}});
  if(!authorized(req)) return send(res,401,{status:false,error:'Unauthorized'});
  if(req.method!=='POST') return send(res,405,{status:false,error:'Method Not Allowed'});
  const data=await jsonBody(req);
  if(u.pathname==='/v1/chat/completions'){
    const r=await fetch(CHAT_URL,{method:'POST',headers:{'Content-Type':'application/json','Accept':'text/event-stream,application/json'},body:JSON.stringify(data)});
    const ct=r.headers.get('content-type')||'text/event-stream'; res.writeHead(r.status,{'Content-Type':ct,'Cache-Control':'no-cache, no-transform','X-Accel-Buffering':'no'});
    if(!r.body)return res.end(); const reader=r.body.getReader(); while(true){const {value,done}=await reader.read();if(done)break;res.write(Buffer.from(value));} return res.end();
  }
  if(u.pathname==='/v1/images/generations') return proxyJson(res,IMAGE_URL,data);
  if(u.pathname==='/v1/images/edits') return proxyJson(res,EDIT_URL,data);
  if(u.pathname==='/v1/search'){
    if(!TAVILY) return send(res,503,{status:false,error:'TAVILY_API_KEY belum dikonfigurasi di VPS 4'});
    const r=await fetch('https://api.tavily.com/search',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({api_key:TAVILY,query:String(data.query||data.question||''),search_depth:'basic',max_results:6})});
    return send(res,r.status,await r.text());
  }
  return send(res,404,{status:false,error:'Route Not Found'});
 }catch(e){return send(res,502,{status:false,error:e.message||'Gateway error'});}
});
server.listen(PORT,'0.0.0.0',()=>console.log(`ONYX Gateway listening on :${PORT}`));
