import http from 'node:http';
import { URL } from 'node:url';
import crypto from 'node:crypto';
import {
  ensureAccount, issueApiKey, findApiKey, getBalance, spendCredits, refundCredits,
  createPaymentRow, getPayment, settlePayment, updatePaymentStatus
} from './db.js';

const PORT = Number(process.env.PORT || 8080);
const SECRET = process.env.GATEWAY_SECRET || '';
const CHAT_URL = process.env.CHAT_URL || 'http://127.0.0.1:8000/v1/chat/completions';
const IMAGE_URL = process.env.IMAGE_URL || 'http://127.0.0.1:8188/generate';
const EDIT_URL = process.env.EDIT_URL || 'http://127.0.0.1:8188/edit';
const TAVILY = process.env.TAVILY_API_KEY || '';
const MIDTRANS_SERVER_KEY = process.env.MIDTRANS_SERVER_KEY || '';
const MIDTRANS_BASE = process.env.MIDTRANS_BASE_URL || 'https://api.midtrans.com';
const COST_CHAT = Number(process.env.COST_CHAT || 1);
const COST_IMAGE = Number(process.env.COST_IMAGE || 5);
const COST_EDIT = Number(process.env.COST_EDIT || 5);
const COST_SEARCH = Number(process.env.COST_SEARCH || 1);

function send(res, status, data, ct = 'application/json; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': ct, 'Cache-Control': 'no-store' });
  res.end(typeof data === 'string' ? data : JSON.stringify(data));
}
async function body(req) { const chunks=[]; for await (const c of req) chunks.push(c); return Buffer.concat(chunks); }
async function jsonBody(req) { const b=await body(req); try{return JSON.parse(b.toString()||'{}')}catch{return {}} }
function gatewayAuthorized(req) { return Boolean(SECRET) && req.headers['x-onyx-gateway-key'] === SECRET; }
function bearer(req) {
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7).trim() : (req.headers['x-onyx-api-key'] || '').trim();
}
function access(req, cost = 0) {
  if (gatewayAuthorized(req)) return { privileged: true, customerId: null, charged: 0 };
  const account = findApiKey(bearer(req));
  if (!account) return { error: 'API key tidak valid atau sudah dicabut', status: 401 };
  if (cost > 0 && !spendCredits(account.customer_id, cost)) return { error: `Saldo credit tidak cukup. Butuh ${cost} credit.`, status: 402 };
  return { privileged: false, customerId: account.customer_id, charged: cost };
}
async function proxyJson(res, url, payload) {
  const r = await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json,text/event-stream,image/*,*/*'},body:JSON.stringify(payload)});
  const ct=r.headers.get('content-type')||''; const b=Buffer.from(await r.arrayBuffer());
  res.writeHead(r.status,{'Content-Type':ct||'application/octet-stream','Cache-Control':'no-store'}); res.end(b);
}
function midtransAuth() { return 'Basic ' + Buffer.from(`${MIDTRANS_SERVER_KEY}:`).toString('base64'); }
function validMidtransSignature(data) {
  if (!MIDTRANS_SERVER_KEY) return false;
  const gross = String(data.gross_amount ?? '');
  const expected = crypto.createHash('sha512').update(String(data.order_id||'')+String(data.status_code||'')+gross+MIDTRANS_SERVER_KEY).digest('hex');
  return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(String(data.signature_key||'')));
}
async function createQrisPayment({customerId, amount, credits}) {
  if (!MIDTRANS_SERVER_KEY) throw new Error('MIDTRANS_SERVER_KEY belum dikonfigurasi di VPS');
  const orderId = `onyx-${crypto.randomBytes(8).toString('hex')}`;
  createPaymentRow(orderId, customerId, amount, credits);
  const r = await fetch(`${MIDTRANS_BASE}/v2/charge`, {
    method:'POST',
    headers:{'Authorization':midtransAuth(),'Content-Type':'application/json','Accept':'application/json'},
    body:JSON.stringify({payment_type:'qris',transaction_details:{order_id:orderId,gross_amount:amount},qris:{acquirer:'gopay'}})
  });
  const text=await r.text(); let data; try{data=JSON.parse(text)}catch{data={raw:text}};
  if(!r.ok){ updatePaymentStatus(orderId,'failed'); throw new Error(data?.status_message||data?.error_messages?.join?.(', ')||`Midtrans HTTP ${r.status}`); }
  return { order_id:orderId, ...data };
}

const server=http.createServer(async(req,res)=>{
  try{
    const u=new URL(req.url,`http://${req.headers.host}`);

    if(u.pathname==='/health') return send(res,200,{status:true,service:'ONYX AI Gateway',architecture:'single-vps',routes:{chat:true,generate:true,edit:true,search:Boolean(TAVILY),api_keys:true,payment:Boolean(MIDTRANS_SERVER_KEY)}});

    // Midtrans webhook: public HTTPS endpoint, protected by signature_key.
    if(u.pathname==='/v1/payment/webhook' && req.method==='POST'){
      const data=await jsonBody(req);
      if(!validMidtransSignature(data)) return send(res,401,{status:false,error:'Invalid Midtrans signature'});
      const order=getPayment(String(data.order_id||''));
      if(!order) return send(res,404,{status:false,error:'Order not found'});
      const status=String(data.transaction_status||'');
      if(['settlement','capture'].includes(status) && String(data.fraud_status||'accept')==='accept') settlePayment(order.order_id,data.payment_type||'qris');
      else if(['expire','cancel','deny'].includes(status)) updatePaymentStatus(order.order_id,status,data.payment_type||null);
      else updatePaymentStatus(order.order_id,status,data.payment_type||null);
      return send(res,200,{status:true});
    }

    // Internal Vercel -> VPS routes use the gateway secret.
    if(u.pathname==='/v1/account/key' && req.method==='POST'){
      if(!gatewayAuthorized(req)) return send(res,401,{status:false,error:'Unauthorized'});
      const data=await jsonBody(req); const customerId=String(data.customer_id||'').trim();
      if(!customerId || customerId.length>120) return send(res,400,{status:false,error:'customer_id wajib diisi'});
      const key=issueApiKey(customerId); return send(res,201,{status:true,customer_id:customerId,api_key:key,warning:'Simpan API key ini. Key plaintext hanya ditampilkan sekali.'});
    }
    if(u.pathname==='/v1/account/balance' && req.method==='POST'){
      if(!gatewayAuthorized(req)) return send(res,401,{status:false,error:'Unauthorized'});
      const data=await jsonBody(req); const customerId=String(data.customer_id||'').trim();
      if(!customerId) return send(res,400,{status:false,error:'customer_id wajib diisi'});
      return send(res,200,{status:true,customer_id:customerId,credits:getBalance(customerId)});
    }
    if(u.pathname==='/v1/payment/create' && req.method==='POST'){
      if(!gatewayAuthorized(req)) return send(res,401,{status:false,error:'Unauthorized'});
      const data=await jsonBody(req); const customerId=String(data.customer_id||'').trim();
      const amount=Math.round(Number(data.amount)); const credits=Math.round(Number(data.credits));
      if(!customerId || !Number.isFinite(amount) || amount<1000 || !Number.isFinite(credits) || credits<1) return send(res,400,{status:false,error:'customer_id, amount (>=1000), dan credits wajib valid'});
      const payment=await createQrisPayment({customerId,amount,credits});
      return send(res,201,{status:true,payment});
    }

    if(req.method!=='POST') return send(res,405,{status:false,error:'Method Not Allowed'});

    let cost=0;
    if(u.pathname==='/v1/chat/completions') cost=COST_CHAT;
    else if(u.pathname==='/v1/images/generations') cost=COST_IMAGE;
    else if(u.pathname==='/v1/images/edits') cost=COST_EDIT;
    else if(u.pathname==='/v1/search') cost=COST_SEARCH;
    const auth=access(req,cost);
    if(auth.error) return send(res,auth.status,{status:false,error:auth.error});

    const data=await jsonBody(req);
    if(u.pathname==='/v1/chat/completions'){
      const r=await fetch(CHAT_URL,{method:'POST',headers:{'Content-Type':'application/json','Accept':'text/event-stream,application/json'},body:JSON.stringify(data)});
      if(!r.ok && auth.charged) refundCredits(auth.customerId,auth.charged);
      const ct=r.headers.get('content-type')||'text/event-stream'; res.writeHead(r.status,{'Content-Type':ct,'Cache-Control':'no-cache, no-transform','X-Accel-Buffering':'no'});
      if(!r.body)return res.end(); const reader=r.body.getReader(); while(true){const {value,done}=await reader.read();if(done)break;res.write(Buffer.from(value));} return res.end();
    }
    if(u.pathname==='/v1/images/generations') { try{return await proxyJson(res,IMAGE_URL,data)}catch(e){if(auth.charged)refundCredits(auth.customerId,auth.charged);throw e;} }
    if(u.pathname==='/v1/images/edits') { try{return await proxyJson(res,EDIT_URL,data)}catch(e){if(auth.charged)refundCredits(auth.customerId,auth.charged);throw e;} }
    if(u.pathname==='/v1/search'){
      if(!TAVILY){if(auth.charged)refundCredits(auth.customerId,auth.charged);return send(res,503,{status:false,error:'TAVILY_API_KEY belum dikonfigurasi di VPS'});}
      const r=await fetch('https://api.tavily.com/search',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({api_key:TAVILY,query:String(data.query||data.question||''),search_depth:'basic',max_results:6})});
      if(!r.ok && auth.charged) refundCredits(auth.customerId,auth.charged); return send(res,r.status,await r.text());
    }
    return send(res,404,{status:false,error:'Route Not Found'});
  }catch(e){return send(res,502,{status:false,error:e.message||'Gateway error'});}
});
server.listen(PORT,'0.0.0.0',()=>{console.log(`ONYX Gateway (single VPS) listening on :${PORT}`);});
